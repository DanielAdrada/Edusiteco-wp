<?php
// Espacio para funciones adicionales futuras
